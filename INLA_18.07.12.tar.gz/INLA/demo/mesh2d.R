demo('mesh2d_run_me', echo=FALSE, package = "INLA")

