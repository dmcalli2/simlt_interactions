library(testthat)
library(INLA)
test_package("INLA")
